<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $order->id !!}</p>
</div>

<!-- Typepapers Id Field -->
<div class="form-group">
    {!! Form::label('typepapers_id', 'Typepapers Id:') !!}
    <p>{!! $order->typepapers_id !!}</p>
</div>

<!-- Typeformat Id Field -->
<div class="form-group">
    {!! Form::label('typeformat_id', 'Typeformat Id:') !!}
    <p>{!! $order->typeformat_id !!}</p>
</div>

<!-- Wordpage Id Field -->
<div class="form-group">
    {!! Form::label('wordpage_id', 'Wordpage Id:') !!}
    <p>{!! $order->wordpage_id !!}</p>
</div>

<!-- Academiclevel Id Field -->
<div class="form-group">
    {!! Form::label('academiclevel_id', 'Academiclevel Id:') !!}
    <p>{!! $order->academiclevel_id !!}</p>
</div>

<!-- Deadline Id Field -->
<div class="form-group">
    {!! Form::label('deadline_id', 'Deadline Id:') !!}
    <p>{!! $order->deadline_id !!}</p>
</div>

<!-- Userslevel Id Field -->
<div class="form-group">
    {!! Form::label('userslevel_id', 'Userslevel Id:') !!}
    <p>{!! $order->userslevel_id !!}</p>
</div>

<!-- Extratservice Id Field -->
<div class="form-group">
    {!! Form::label('extratservice_id', 'Extratservice Id:') !!}
    <p>{!! $order->extratservice_id !!}</p>
</div>

<!-- Bonreduction Id Field -->
<div class="form-group">
    {!! Form::label('bonreduction_id', 'Bonreduction Id:') !!}
    <p>{!! $order->bonreduction_id !!}</p>
</div>

<!-- Etat Id Field -->
<div class="form-group">
    {!! Form::label('etat_id', 'Etat Id:') !!}
    <p>{!! $order->etat_id !!}</p>
</div>

<!-- Typeofwork Id Field -->
<div class="form-group">
    {!! Form::label('typeofwork_id', 'Typeofwork Id:') !!}
    <p>{!! $order->typeofwork_id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $order->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $order->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $order->deleted_at !!}</p>
</div>

