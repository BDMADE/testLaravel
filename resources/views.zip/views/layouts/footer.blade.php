
<!-- ====== Copyright Section ====== -->
<section class="copyright dark-bg">
    <div class="container">
        <p>&copy; {!! date('Y') !!} <a href="{!! url('/') !!}">{!! config('app.name') !!}</a>, All Rights Reserved</p>
    </div> <!-- end .container -->
</section>
<!-- ====== End Copyright Section ====== -->

