<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $userslevel->id !!}</p>
</div>

<!-- Nom Field -->
<div class="form-group">
    {!! Form::label('nom', 'Nom:') !!}
    <p>{!! $userslevel->nom !!}</p>
</div>

<!-- Prix Percent Field -->
<div class="form-group">
    {!! Form::label('prix_percent', 'Prix Percent:') !!}
    <p>{!! $userslevel->prix_percent !!}</p>
</div>

<!-- Prix Fixe Field -->
<div class="form-group">
    {!! Form::label('prix_fixe', 'Prix Fixe:') !!}
    <p>{!! $userslevel->prix_fixe !!}</p>
</div>

<!-- Appliquer Prixfixe Field -->
<div class="form-group">
    {!! Form::label('appliquer_prixfixe', 'Appliquer Prixfixe:') !!}
    <p>{!! $userslevel->appliquer_prixfixe !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $userslevel->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $userslevel->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $userslevel->deleted_at !!}</p>
</div>

