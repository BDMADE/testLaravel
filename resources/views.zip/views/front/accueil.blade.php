@extends('layouts.template')




@section('header')
    @include('front.header')
@endsection


@section('menu')
    @include('layouts.menu')
@endsection

@section('content')
<!-- ====== Features Section ====== -->
<!--section id="ourservice" style="background-color: #d1d8e03d; padding-bottom:100px;">
    <div class="features section-padding no-padding-bottom">
        <div class="container">

            <div class="header">
                <i class="fa fa-headphones" style="color: #ebbb2e; text-align: center; font-size: 8em;"></i>
                <h1>Get Help from Experts</h1>
                <p> Struggling with your assignments, essay or Dissertation ?</p>
                <p> Give your self a peace of mind with our professional writers for any subject, deadline and any complexity. We provide 100% confidential and plagiarism free papers with guaranteed grade. </p>
                <p>
                    <i class="fa fa-paypal" style="color: #1B9CFC;"></i> Payment after Complete work <br>
                    <i class="fa fa-cc-paypal" style="color: #1B9CFC;"></i>
                    <i class="fa fa-credit-card" style="color: #eb4d4b;"></i>
                    Paypal and All Credit Card Accepted!
                </p>

            </div>
        </div>

    </div>
</section-->

<section id="presentation">
    <div class="features section-padding no-padding-bottom">
        <div class="container">

            <div class="row">
                <div class="header">
                    <h1>Enhance Your Academic Grades and Skills with Our Experts</h1>

                    <p> Our fields of experts, and our s/hport and team of writers, proofreader and quality assurers
                        strived to give you nothing but the best, our work quality is all you need! The features includes:
                    </p>

                </div>
                <div class="col-sm-4 hidden-xs">
                    <div class="featured-item-img">
                        <i class="fa fa-graduation-cap" style="color: #0a3d62; text-align: center; font-size: 12em;"></i><br>
                        <i class="fa fa-user" style="color: #6a89cc; text-align: center; font-size: 20em; margin-top: -0.1em; margin-left: -0.10em;"></i>

                        <!--img src="{{asset('images/prise_de_notes_bloc_note.png')}}" alt=""-->
                    </div>
                </div>
                <div class="col-sm-8 col-xs-12 feature-list">
                    <div class="row">

                        <div class="col-sm-6 col-md-6">
                            <div class="featured-item">
                                <div class="icon">
                                    <div class="icon-style"><i class="fa fa-clock-o" ></i></div>
                                </div> <!-- end icon -->
                                <div class="meta-text">
                                    <h3>On Time Delivery </h3>
                                    <p>All paper are delivered in due time.</p>
                                </div> <!-- end .meta-text -->
                            </div> <!-- end .featured-item -->
                        </div> <!-- end .feature-list> .row > .col-md-6 (1st item) -->

                        <div class="col-sm-6 col-md-6">
                            <div class="featured-item">
                                <div class="icon">
                                    <div class="icon-style"><i class="fa fa-refresh"></i></div>
                                </div> <!-- end icon -->
                                <div class="meta-text">
                                    <h3>Unlimited Revision</h3>
                                    <p>Get unlimited revision as long as you need.</p>
                                </div> <!-- end .meta-text -->
                            </div> <!-- end .featured-item -->
                        </div> <!-- end .feature-list> .row > .col-md-6 (2nd item) -->

                        <div class="col-sm-6 col-md-6">
                            <div class="featured-item">
                                <div class="icon">
                                    <div class="icon-style"><i class="fa fa-headphones"></i></div>
                                </div> <!-- end icon -->
                                <div class="meta-text">
                                    <h3>24/7 Support</h3>
                                    <p>Our friendly experts are always available to serve you!</p>
                                </div> <!-- end .meta-text -->
                            </div> <!-- end .featured-item -->
                        </div> <!-- end .feature-list> .row > .col-md-6 (3rd item) -->

                        <div class="col-sm-6 col-md-6">
                            <div class="featured-item">
                                <div class="icon">
                                    <div class="icon-style"><i class="fa fa-copyright" aria-hidden="true"></i></div>
                                </div> <!-- end icon -->
                                <div class="meta-text">
                                    <h3>100% Plagiarism Free</h3>
                                    <p>All the work are original research and properly referenced .</p>
                                </div> <!-- end .meta-text -->
                            </div> <!-- end .featured-item -->
                        </div> <!-- end .feature-list> .row > .col-md-6 (4th item) -->

                        <div class="col-sm-6 col-md-6">
                            <div class="featured-item">
                                <div class="icon">
                                    <div class="icon-style"><i class="fa fa-paypal"></i></div>
                                </div> <!-- end icon -->
                                <div class="meta-text">
                                    <h3>Payment after 100% satisfaction</h3>
                                    <p>Split your payment, and pay the final amount upon satisfied work quality.</p>
                                </div> <!-- end .meta-text -->
                            </div> <!-- end .featured-item -->
                        </div> <!-- end .feature-list> .row > .col-md-6 (5th item) -->

                        <div class="col-sm-6 col-md-6">
                            <div class="featured-item">
                                <div class="icon">
                                    <div class="icon-style"><i class="fa fa-lock"></i></div>
                                </div> <!-- end icon -->
                                <div class="meta-text">
                                    <h3>100% privacy and Confidential</h3>
                                    <p>We do not collect or share any of your information with anyone!.</p>
                                </div> <!-- end .meta-text -->
                            </div> <!-- end .featured-item -->
                        </div> <!-- end .feature-list> .row > .col-md-6 (6th item) -->

                    </div> <!-- end .feature-list> .row -->
                </div> <!-- end .feature-list -->
            </div> <!-- end .container> .row -->

        </div> <!-- end .container -->

        <div class="container">
            <div class="row">
                <div class="col-xs-12 center">
                    <a href="{{url('order')}}" class="btn btn-lg btn-link btn-order"> Order now </a>
                </div>
            </div>
        </div>

    </div> <!-- end .features -->
</section>
<!-- ====== End Features Section ====== -->

<style>

    .bloc-elm-5{
        width: 19%;
        margin-right: 1%;
        float: left;
    }
    @media screen and (max-width: 700px) {
        .bloc-elm-5{
            width: 98%;
            margin-right: 1%;
            float: left;
        }
    }

</style>

<!-- ====== Download Section ====== -->
<section id="download">
    <div class="bg-color">
        <div class="download section-padding">
            <div class="container">

                <div class="header">
                    <h1> <strong>How does it work ?</strong></h1>
                    <div class="underline"><i class="fa fa-cog"></i></div>
                </div> <!-- end .container > .header -->

                <div class="row download-area">

                    <div class="bloc-elm-5 how-it-works no-padding">
                        <div class="header-how-it-works">
                            <span>1. Submit Order Details </span>
                        </div>
                        <i class="fa fa-chevron-right"></i>
                        <div class="explane-how-it-works">
                            <p>
                                Placing an order with us is very easy with features to provide all your instructions and requirements and get a customized low cost.
                            </p>
                        </div> <!-- end .download-area> .col-lg-3 (1) -->
                    </div> <!-- end .download-area> .col-lg-3 (1) -->

                    <div class="bloc-elm-5 how-it-works no-padding">
                        <div class="header-how-it-works">
                            <span>2. Instructions Reviews and Discussions </span>
                        </div>
                        <i class="fa fa-chevron-right"></i>
                        <div class="explane-how-it-works">
                            <p>
                                All the instructions are reviewed and discussed between writers and experts, and prepare the writers to get started in no time.
                            </p>
                        </div> <!-- end .download-area> .col-lg-3 (1) -->
                    </div> <!-- end .download-area> .col-lg-3 (2) -->

                    <div class="bloc-elm-5 how-it-works no-padding">
                        <div class="header-how-it-works">
                            <span>3. Paper Sent to You and Quality Team</span>
                        </div>
                        <i class="fa fa-chevron-right"></i>
                        <div class="explane-how-it-works">
                            <p>
                                Once paper is done, we sent to you and also our quality control team, with your and quality control feedback, we thrive to bring better output.
                            </p>
                        </div> <!-- end .download-area> .col-lg-3 (1) -->
                    </div> <!-- end .download-area> .col-lg-3 (3) -->

                    <div class="bloc-elm-5 how-it-works no-padding">
                        <div class="header-how-it-works">
                            <span>4. Revision and Proofread</span>
                        </div>
                        <i class="fa fa-chevron-right"></i>
                        <div class="explane-how-it-works">
                            <p>
                                The feedback from you and quality controller are taken into consideration and revision are done promptly and you can access after login to our site.
                            </p>
                        </div> <!-- end .download-area> .col-lg-3 (1) -->
                    </div> <!-- end .download-area> .col-lg-3 (4) -->

                    <div class="bloc-elm-5 how-it-works no-padding">
                        <div class="header-how-it-works-last">
                            <span>5. Satisfied!!! Complete your Payment</span>
                        </div>
                        <div class="explane-how-it-works">
                            <p>
                                Once you get your complete paper, you can review the paper, and once you are satisfied, you can pay the final amount at the after login dashboard.
                            </p>
                        </div> <!-- end .download-area> .col-lg-3 (1) -->
                    </div> <!-- end .download-area> .col-lg-3 (4) -->

                </div> <!-- end .container > .row/.download-area -->

            </div> <!-- end .container -->

            <div class="container">
                <div class="row">
                    <div class="col-xs-12 center">
                        <a href="{{url('order')}}" class="btn btn-lg btn-link btn-order"> Order now </a>
                    </div>
                </div>
            </div>
        </div> <!-- end .download -->
    </div> <!-- end .bg-color -->
</section>
<!-- ====== End Download Section ====== -->



<!-- ====== Screenshots Section ====== -->
<section id="ourstats">
    <div class="price section-padding dark-bg">
        <div class="container-fluid">

            <div class="header">
                <h1 style="font-size: 2em;">Our service includes anything from writing, guiding and proofreading </h1>
                <p>If you are stressed with anything throughout your study, our service covers you. Whether its your understanding or your missing lectures bothers you or you simply want a better grades, whatever it it, and whatever the situation you are in, we are to help, just simply fill out the form or chat with our support staff. </p>
                <div class="underline"><i class="fa fa-edit"></i></div>
            </div>

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="">
                    <div class="col-xs-12 ">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 stat no-padding">
                            <h2 class="titre-bloc-service">
                                Essay services</h2>
                            <div class="underline1"><i class="fa fa-cog"></i></div>
                            <div class="col-sm-12 col-xs-12 list-paragraph no-padding">
                                <p class="" >Essay writting service</p>
                                <p class="" >Assignment writing service </p>
                                <p class="" >Coursework wrinting service</p>
                                <p class="" >Essay outline / Plan service</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 stat no-padding">
                            <h2 class="titre-bloc-service">
                                Dissertation Services</h2>
                            <div class="underline1"><i class="fa fa-cog"></i></div>
                            <div class="col-sm-12 col-xs-12 list-paragraph no-padding">
                                <p class="" >Dissertation writting service</p>
                                <p class="" >Dissertation proposal service </p>
                                <p class="" >Topic with title service</p>
                                <p class="" >literature review service</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 stat no-padding">
                            <h2 class="titre-bloc-service">
                                Report writing</h2>
                            <div class="underline1"><i class="fa fa-cog"></i></div>
                            <div class="col-sm-12 col-xs-12 list-paragraph no-padding">
                                <p class="" >Report Writing service</p>
                                <p class="" >Reflective practice service </p>
                                <p class="" >Research report service</p>
                                <p class="" >Report correcting service</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 stat no-padding">
                            <h2 class="titre-bloc-service">
                                Other</h2>
                            <div class="underline1"><i class="fa fa-cog"></i></div>
                            <div class="col-sm-12 col-xs-12 list-paragraph no-padding">
                                <p class="" >Proofreading service</p>
                                <p class="" >Exam revision service </p>
                                <p class="" >Presentation service</p>
                                <p class="" >Making and guiding service</p>
                                <p class="" >Tutoring service</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end owl carousel -->

        </div> <!-- .container -->

        <div class="container">
            <div class="row">
                <div class="col-xs-12 center">
                    <a href="{{url('order')}}" class="btn btn-lg btn-link btn-order"> Order now </a>
                </div>
            </div>
        </div>
    </div> <!-- end .screenshots -->
</section>
<!-- ====== End Screenshots Section ====== -->



<!-- ====== Testimonial Section ====== -->
<!--section id="testimonial">
    <div class="bg-color bg-testimonial">
        <div class="testimonial section-padding">
            <div class="container">
                <div class="testimonial-slide">

                    <div class="testimonial-header">
                        <h1> <strong>what our customers say</strong></h1>
                        <div class="underline small-margin-bottom"><i class="fa fa-cog"></i></div>
                    </div>


                    <div id="carousel-testimonial" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-testimonial" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-testimonial" data-slide-to="1" class=""></li>
                            <li data-target="#carousel-testimonial" data-slide-to="2" class=""></li>
                        </ol>
                        <div class="carousel-inner">

                            <div class="item">
                                <div class="image">
                                    <img src="{{asset('images/01.jpg')}}" alt="">
                                </div>
                                <div class="content">
                                    <p class="block-customer-name">
                                        <strong>Jon Doe (Web developer)</strong>
                                        <span class="note">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </span>
                                    </p>
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut dignissimos ipsam obcaecati
                                        corrupti modi, deserunt facere asperiores. Voluptatum laudantium ut, minus nam. Libero
                                        facilis aspernatur cumque, quisquam quod sint odit.
                                    </p>
                                </div>
                            </div>

                            <div class="item active left">
                                <div class="image">
                                    <img src="{{asset('images/02.jpg')}}" alt="">
                                </div>
                                <div class="content">
                                    <p class="block-customer-name">
                                        <strong>Jon Doe (Web developer)</strong>
                                        <span class="note">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </span>
                                    </p>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut dignissimos ipsam obcaecati corrupti modi, deserunt facere asperiores. Voluptatum laudantium ut, minus nam. Libero facilis aspernatur cumque, quisquam quod sint odit.</p>

                                </div>
                            </div>

                            <div class="item next left">
                                <div class="image">
                                    <img src="{{asset('images/03.jpg')}}" alt="">
                                </div>
                                <div class="content">
                                    <p class="block-customer-name">
                                        <strong>Jon Doe (Web developer)</strong>
                                        <span class="note">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </span>
                                    </p>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut dignissimos ipsam obcaecati corrupti modi, deserunt facere asperiores. Voluptatum laudantium ut, minus nam. Libero facilis aspernatur cumque, quisquam quod sint odit.</p>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-xs-12 center">
                        <a href="{{url('order')}}" class="btn btn-lg btn-link btn-order"> Order now </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section-->
<!-- ====== End Testimonial Section ====== -->



<!-- ====== Price Section ====== -->
<!--section  class="services" id="domaine">
    <div class="price section-padding dark-bg">
        <div class="container">

            <div class="header">
                <h1>Type of paper</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui hic laboriosam odio doloribus suscipit error nostrum totam dignissimos esse numquam voluptatum, aspernatur est, at voluptatem minus</p>
                <div class="underline small-margin-bottom"><i class="fa fa-file-text-o"></i></div>
            </div>

            <div class="row">
                <ul class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <li><a href="#">Admission essay</a></li>
                    <li><a href="#">Annotated bibliography</a></li>
                    <li><a href="#">Application letter</a></li>
                    <li><a href="#">Argumentative essay</a></li>
                </ul>
                <ul class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <li><a href="#">Article</a></li>
                    <li><a href="#">Article review</a></li>
                    <li><a href="#">Biography</a></li>
                    <li><a href="#">Book review</a></li>
                </ul>
                <ul class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <li><a href="#">Business plan</a></li>
                    <li><a href="#">Case study</a></li>
                    <li><a href="#">Course work</a></li>
                    <li><a href="#">Cover letter</a></li>
                </ul>
                <ul class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <li><a href="#">Creative writing</a></li>
                    <li><a href="#">Critical thinking</a></li>
                    <li><a href="#">Curriculum vitae</a></li>
                    <li><a href="#">Dissertation</a></li>
                </ul>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <a  href="#" class="view-all pull-right">View all
                        <i class="fa fa-long-arrow-right"></i>
                    </a>
                </div>
            </div>

        </div>

        <div class="container">
            <div class="row">
                <div class="col-xs-12 center">
                    <a href="{{url('order')}}" class="btn btn-lg btn-link btn-order"> Order now </a>
                </div>
            </div>
        </div>
    </div>
</section-->
<!-- ====== End Price Section ====== -->



@include('front.contactBloc')



@endsection





@section('scripts')
    <script src="{{asset('js/my.js')}}"></script>



@endsection

