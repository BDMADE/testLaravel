<div class="modal fade loginModal" id="emailModal">
    <div class="modal-dialog  modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-body full-transparents">
                @include('auth.passwords.emailForm')
            </div>
        </div>
    </div>
</div>