@extends('layouts.appAdmin')

@section('css')
    <link rel="stylesheet" href="{{asset('css/monstyle.css')}}">
@endsection

@section('content')
    <?php
    //die();
    $user = auth()->user();
    ?>
    <div class="container">
        <div class="row">

            <div style="padding-left: 12px;">
                <a href="{!! route('see-bidding-orders') !!}" class="btn btn-sm btn-success">see bidding orders</a>
            </div>

            @include('users.Admin.globalStat')


            <div class="col-xs-12 general-stats">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Admin User</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>avartar</th>
                                    <th>role</th>
                                    <th>phone</th>
                                    <th>created at</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody id="user_admin">
                                <?php $i = 0; ?>
                                @foreach($user->userAllAdmin() as $usr)
                                    @if($usr->role->slug == 'admin' || $usr->role->slug == 'superadmin' )
                                        <tr id="user_{!! $usr->id !!}">
                                            <td>{!! $usr->name !!}</td>
                                            <td class="avatar">
                                                @if(!is_null($usr->avatar) && $usr->avatar != "")
                                                    <img src="{{asset("images/avatars/".$usr->avatar)}}" class=""/>
                                                @else
                                                    @if($usr->sexe != "feminin")
                                                        <img src="{{asset("images/avatars/default_male.png")}}" class=""/>
                                                    @else
                                                        <img src="{{asset("images/avatars/default_female.png")}}" class=""/>
                                                    @endif
                                                @endif
                                            </td>
                                            <td>

                                                <span class="label label-warning"  id="label_role_{!! $usr->id !!}">{!! $usr->role->name !!}</span>
                                                <br>
                                                change to  <i class="fa fa-spinner fa-spin hidden" id="role_loader_{!! $usr->id !!}"></i>

                                                <span id="error_role_{!! $usr->id !!}" class="error"></span>
                                                <select id="role_{!! $usr->id !!}"  class="form-control"
                                                        onchange="changeRoleUser({!! $usr->id !!}, this.value, '{!! $usr->role->slug !!}')">
                                                    @foreach($roles as $role)
                                                        <option value="{!! $role->id !!}" {!! ($usr->role->id == $role->id)? 'selected' : '' !!}>
                                                            {!! $role->name !!}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td>
                                                @if(!is_null($usr->pay_id))
                                                    (+{!! $usr->pay->indicatif_tel !!})
                                                @endif
                                                {!! $usr->tel1 !!} {!! !is_null($usr->tel2) ? ' / '.$usr->tel2 : '' !!}
                                            </td>
                                            <td>{!! $usr->created_at->format('d M. Y') !!}</td>
                                            <td>
                                                <a href="{!! route('edit-user', $usr->id) !!}" class='btn btn-info btn-xs'>
                                                    <i class="fa fa-edit"></i>
                                                </a>

                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    @endif
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>




            <div class="col-xs-12 general-stats">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Customers</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>avartar</th>
                                    <th>phone</th>
                                    <th>role</th>
                                    <th>created at</th>
                                </tr>
                                </thead>
                                <tbody id="user_customers">
                                <?php $i = 0; ?>
                                @foreach($user->userAllAdmin() as $usr)
                                    @if($usr->role->slug != 'admin' && $usr->role->slug != 'superadmin' )
                                        <tr id="user_{!! $usr->id !!}">
                                            <td>{!! $usr->name !!}</td>
                                            <td class="avatar">
                                                @if(!is_null($usr->avatar) && $usr->avatar != "")
                                                    <img src="{{asset("images/avatars/".$usr->avatar)}}" class=""/>
                                                @else
                                                    @if($usr->sexe != "feminin")
                                                        <img src="{{asset("images/avatars/default_male.png")}}" class=""/>
                                                    @else
                                                        <img src="{{asset("images/avatars/default_female.png")}}" class=""/>
                                                    @endif
                                                @endif
                                            </td>
                                            <td>

                                                <span class="label label-warning"  id="label_role_{!! $usr->id !!}">{!! $usr->role->name !!}</span>
                                                <br>
                                                change to  <i class="fa fa-spinner fa-spin hidden" id="role_loader_{!! $usr->id !!}"></i>

                                                <span id="error_role_{!! $usr->id !!}" class="error"></span>
                                                <select id="role_{!! $usr->id !!}"  class="form-control"
                                                        onchange="changeRoleUser({!! $usr->id !!}, this.value, '{!! $usr->role->slug !!}')">
                                                    @foreach($roles as $role)
                                                        <option value="{!! $role->id !!}" {!! ($usr->role->id  == $role->id)? 'selected' : '' !!}>
                                                            {!! $role->name !!}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td>
                                                @if(!is_null($usr->pay_id))
                                                    (+{!! $usr->pay->indicatif_tel !!})
                                                @endif
                                                {!! $usr->tel1 !!} {!! !is_null($usr->tel2) ? ' / '.$usr->tel2 : '' !!}
                                            </td>
                                            <td>{!! $usr->created_at->format('d M. Y') !!}</td>
                                            <td>
                                                <a href="{!! route('edit-user', $usr->id) !!}" class='btn btn-info btn-xs'>
                                                    <i class="fa fa-edit"></i>
                                                </a>

                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    @endif
                                @endforeach

                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>




        </div>
    </div>

@endsection




@section('scripts')
    <script src="{{asset('js/my.js')}}"></script>

    <script>

        window.token = '{!! csrf_token() !!}';
        window.base_url = '{!! url('/') !!}';
        window.logo = '{{asset('images/logo.png')}}';
        //window.geturl = '{{route('get-last-message')}}';


    </script>


@endsection

